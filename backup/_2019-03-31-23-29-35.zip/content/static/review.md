<!--t Отзывы наших клиентов t-->
<!--d Отзывы клиентов о работе компании СКС d-->

 <section id="page-content">
	<div class="container">
      <div class="heading wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="300ms">
        <div class="row">
          <div class="text-center col-sm-8 col-sm-offset-2">
				<h1>Отзывы наших клиентов</h1>
          </div>
        </div> 
      </div>
	  
      <div class="projects-members">
        <div class="row equal">
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv1.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv6.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv11.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv16.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv7.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv12.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv3.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv8.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv13.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv4.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv9.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv15.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv5.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href=""><img class="img-responsive" src="/themes/my/assets/images/review/otziv10.jpg" alt="отзыв клиента - документ"></a> 
					</div>
					<div class="member-info">
						<h3><span class="pull-left"><i class="fas fa-quote-left"></i></span>Заголовок отзыва</h3>
						<p>цитата из отзыва...</p>
						<p>– Автор отзыва<p>
					</div>
				</div>
            </div>
          </div>
        </div>
	</div>
  </section><!--/#page-content-->
