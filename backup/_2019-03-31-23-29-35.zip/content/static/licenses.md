<!--t Лицензии t-->
<!--d Лицензии компании СКС d-->

 <section id="page-content">
	<div class="container">
      <div class="heading wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="300ms">
        <div class="row">
          <div class="text-center col-sm-8 col-sm-offset-2">
				<h1>Лицензии</h1>
          </div>
        </div> 
      </div>
	  
      <div class="projects-members">
        <div class="row equal">
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href="/themes/my/assets/images/license/12a.jpg" data-lightbox="license"><img class="img-responsive" src="/themes/my/assets/images/license/12as.jpg" alt="Свидетельство СРО Объединение строителей Санкт-Петербурга"></a> 
					</div>
					<div class="member-info">
						<h3>Свидетельство СРО «Объединение строителей Санкт-Петербурга» № 0692.03-2010-7810071193-С-003</h3>
						<p>"О допуске к определенному виду или видам работам, которые оказывают влияние на безопасность объектов капитального строительства" от 7 июня 2013 года</p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href="/themes/my/assets/images/license/30n.jpg" data-lightbox="license"><img class="img-responsive" src="/themes/my/assets/images/license/30ns.jpg" alt="Свидетельство СРО Некоммерческое партнерство Гильдия архитекторов и инженеров Петербурга"></a> 
					</div>
					<div class="member-info">
						<h3>Свидетельство СРО Некоммерческое партнерство «Гильдия архитекторов и инженеров Петербурга» № 0121/2-2013/624-7810071193-II-73</h3>
						<p>"О допуске к определенному виду или видам работам, которые оказывают влияние на безопасность объектов капитального строительства" от 3 июня 2013 года</p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href="/themes/my/assets/images/license/sro.jpg" data-lightbox="license"><img class="img-responsive" src="/themes/my/assets/images/license/svid_sm.jpg" alt="Свидетельство СРО Объединение строителей Санкт-Петербурга"></a> 
					</div>
					<div class="member-info">
						<h3>Свидетельство СРО «Объединение строителей Санкт-Петербурга» № 0692-2010-7810071193-С-3</h3>
						<p>О допуске к работам, которые оказывают влияние на безопасность объектов капитального строительства.</p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href="/themes/my/assets/images/license/scsb.jpg" data-lightbox="license"><img class="img-responsive" src="/themes/my/assets/images/license/scs.jpg" alt="Лицензия МЧС РФ"></a> 
					</div>
					<div class="member-info">
						<h3>Лицензия МЧС РФ № 2-2/00505 от 5 марта 2010 года</h3>
						<p>На осуществление производства работ по монтажу, ремонту и обслуживанию средств обеспечения пожарной безопасности зданий и сооружений.</p>
					</div>
				</div>
            </div>
			<div class="col-lg-4 col-sm-6">
				<div class="projects-member wow flipInY" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="member-image">
						<a href="/themes/my/assets/images/license/license5-tyco.jpg" data-lightbox="license"><img class="img-responsive" src="/themes/my/assets/images/license/license5.jpg" alt="Лицензия на установку оборудования Tyco electronics"></a> 
					</div>
					<div class="member-info">
						<h3>Лицензия на установку оборудования "Tyco electronics"</h3>
						<p></p>
					</div>
				</div>
            </div>
          </div>
        </div>
	</div>
  </section><!--/#page-content-->
